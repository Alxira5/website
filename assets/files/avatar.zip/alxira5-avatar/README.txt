==============
Alxira5 Avatar
==============

My avatar is the way I present myself on the internet and in turn, a way not to
show my face. I designed my avatar in Inkscape a long time ago as a way of
learning, but I really liked its result and for that reason I have used it
since then.

Its design is very basic so to speak, since it's just a circle with glasses and
a very strange smile, which is inspired by the design of some anime characters.

License
=======

Being a very simple avatar, I decided to release it into the public domain and
you can do whatever you want with it, as long as it is with good intentions.

I recommend using it for informational or learning purposes, and in turn I
recommend modifying it if you want to use it to represent something in
particular.
